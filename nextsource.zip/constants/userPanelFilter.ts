export const userPanelFilter = [
    {
        title: 'جدید',
        href: 'newest',
        id: 1
    },
    {
        title: 'قدیمی',
        href: 'oldest',
        id: 2
    },
    {
        title: 'گران',
        href: 'expensive',
        id: 3
    },
    {
        title: 'ارزان',
        href: 'inexpensive',
        id: 4
    }
]