export const filters = [
    {
        id: 1,
        title: 'جدید ترین',
        value: 'newest'
    },
    {
        id: 2,
        title: 'محبوب ترین',
        value: 'popular'
    },
    {
        id: 3,
        title: 'پرفروش ترین',
        value: 'bestseller'
    },
    {
        id: 4,
        title: 'گران ترین',
        value: 'expensive'
    },
    {
        id: 5,
        title: 'ارزان ترین',
        value: 'inexpensive'
    },
]