export const userPanelTicketFilter = [
    {
        title: 'جدید',
        href: 'newest',
        id: 1
    },
    {
        title: 'قدیمی',
        href: 'oldest',
        id: 2
    }
]