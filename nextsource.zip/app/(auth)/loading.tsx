const Loading = () => {
    return (
        <div className="flex items-center justify-center h-screen">
            <div className="donut z-10">
            </div>
        </div>
    )
}

export default Loading