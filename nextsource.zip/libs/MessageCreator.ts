export const MessageCreator = (state: boolean, message: string) => {
    return { state, message }
}