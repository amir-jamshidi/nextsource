import toast from "react-hot-toast";

export default function () {
    // toast.promise(promise, { loading: 'Saving...', success: null });
}